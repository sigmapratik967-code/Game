package com.voidxen.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Game-styled UI (dialogs, choice lists, toggle, toast) so nothing looks like stock Android. */
class GameUi(private val ctx: Context, private val root: FrameLayout) {

    class Btn(val label: String, val primary: Boolean, val onClick: () -> Unit)

    private val yellow = Color.parseColor("#F7CA2A")
    private val btnText = Color.parseColor("#2D1457")
    private val dim = Color.parseColor("#B9ABD3")
    private val panelColor = Color.parseColor("#2B1650")
    private val stroke = Color.parseColor("#4A2A75")
    private val offTrack = Color.parseColor("#4A2A75")
    private val offKnob = Color.parseColor("#CFC2E6")

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private val toastView: TextView? = root.findViewById(R.id.toastView)
    private val hideToast = Runnable {
        toastView?.animate()?.alpha(0f)?.setDuration(200)?.withEndAction { toastView.visibility = View.GONE }?.start()
    }

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private fun text(s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun pill(fill: Int, strokeW: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(4).toFloat()
        if (strokeW > 0) g.setStroke(strokeW, yellow)
        return g
    }

    // ---------------------------------------------------------------- toast
    fun toast(msg: String) {
        val t = toastView ?: return
        handler.removeCallbacks(hideToast)
        t.animate().cancel()
        t.text = msg
        t.visibility = View.VISIBLE
        t.alpha = 0f
        t.animate().alpha(1f).setDuration(160).start()
        handler.postDelayed(hideToast, 2600L)
    }

    // ---------------------------------------------------------------- dialog
    fun dismissDialog(): Boolean {
        val o = overlay ?: return false
        overlay = null
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(o.windowToken, 0)
        o.animate().alpha(0f).setDuration(120).withEndAction { root.removeView(o) }.start()
        return true
    }

    fun dialog(title: String, message: String?, content: View?, buttons: List<Btn>, cancelable: Boolean = true) {
        dismissDialog()
        val dm = ctx.resources.displayMetrics

        val scrim = FrameLayout(ctx)
        scrim.setBackgroundColor(Color.parseColor("#B3050010"))
        scrim.isClickable = true
        if (cancelable) scrim.setOnClickListener { dismissDialog() }

        val panel = LinearLayout(ctx)
        panel.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(panelColor)
        bg.cornerRadius = dp(10).toFloat()
        bg.setStroke(dp(1), stroke)
        panel.background = bg
        panel.setPadding(dp(22), dp(18), dp(22), dp(16))
        panel.isClickable = true

        panel.addView(text(title, 18f, Color.WHITE, true))
        if (message != null) {
            val m = text(message, 13f, dim)
            m.setPadding(0, dp(8), 0, 0)
            panel.addView(m)
        }
        if (content != null) {
            val sv = MaxHeightScroll(ctx, (dm.heightPixels * 0.5f).toInt())
            sv.addView(content)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(12)
            panel.addView(sv, lp)
        }

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.END
        buttons.forEachIndexed { i, b ->
            val t = text(b.label, 14f, if (b.primary) btnText else yellow, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(20), 0, dp(20), 0)
            t.minWidth = dp(92)
            t.background = if (b.primary) pill(yellow, 0) else pill(Color.TRANSPARENT, dp(1))
            t.setOnClickListener {
                dismissDialog()
                b.onClick()
            }
            val lp = LinearLayout.LayoutParams(-2, dp(40))
            if (i > 0) lp.marginStart = dp(10)
            row.addView(t, lp)
        }
        val rlp = LinearLayout.LayoutParams(-1, -2)
        rlp.topMargin = dp(18)
        panel.addView(row, rlp)

        val w = minOf(dp(460), (dm.widthPixels * 0.92f).toInt())
        scrim.addView(panel, FrameLayout.LayoutParams(w, -2, Gravity.CENTER))
        scrim.alpha = 0f
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        scrim.animate().alpha(1f).setDuration(160).start()
        overlay = scrim
    }

    fun confirm(title: String, message: String, okLabel: String, cancelLabel: String, onOk: () -> Unit) {
        dialog(title, message, null, listOf(Btn(cancelLabel, false) { }, Btn(okLabel, true) { onOk() }))
    }

    // radio list (replaces the stock Android single-choice dialog)
    fun choice(title: String, items: List<String>, selected: Int, cancelLabel: String, onPick: (Int) -> Unit) {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        items.forEachIndexed { i, label ->
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(6), dp(12), dp(6), dp(12))
            row.isClickable = true
            row.setOnClickListener {
                dismissDialog()
                onPick(i)
            }
            row.addView(radio(i == selected), LinearLayout.LayoutParams(dp(22), dp(22)))
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.marginStart = dp(14)
            row.addView(text(label, 15f, Color.WHITE), lp)
            box.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        dialog(title, null, box, listOf(Btn(cancelLabel, false) { }))
    }

    private fun radio(on: Boolean): View {
        val f = FrameLayout(ctx)
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.OVAL
        ring.setColor(Color.TRANSPARENT)
        ring.setStroke(dp(2), if (on) yellow else dim)
        f.background = ring
        if (on) {
            val dot = View(ctx)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(yellow)
            dot.background = g
            f.addView(dot, FrameLayout.LayoutParams(dp(10), dp(10), Gravity.CENTER))
        }
        return f
    }

    // text input in the same style
    fun input(
        title: String, message: String, hint: String, initial: String,
        saveLabel: String, resetLabel: String, cancelLabel: String,
        onSave: (String) -> Unit, onReset: () -> Unit
    ) {
        val et = EditText(ctx)
        et.setText(initial)
        et.hint = hint
        et.setHintTextColor(Color.parseColor("#8E7FAD"))
        et.setTextColor(Color.WHITE)
        et.textSize = 14f
        et.setSingleLine(true)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        et.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_ACTION_DONE
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#2A1048"))
        bg.cornerRadius = dp(6).toFloat()
        bg.setStroke(dp(1), stroke)
        et.background = bg
        et.setPadding(dp(14), dp(10), dp(14), dp(10))
        dialog(
            title, message, et,
            listOf(
                Btn(cancelLabel, false) { },
                Btn(resetLabel, false) { onReset() },
                Btn(saveLabel, true) { onSave(et.text.toString().trim()) }
            )
        )
    }

    // ---------------------------------------------------------------- toggle (replaces the stock Switch)
    fun toggle(checked: Boolean, onChange: (Boolean) -> Unit): View {
        val w = dp(48)
        val h = dp(26)
        val k = dp(18)
        var on = checked
        val track = FrameLayout(ctx)
        val knob = View(ctx)
        val klp = FrameLayout.LayoutParams(k, k, Gravity.CENTER_VERTICAL)
        klp.marginStart = dp(4)
        track.addView(knob, klp)

        fun render(animate: Boolean) {
            val tb = GradientDrawable()
            tb.cornerRadius = h / 2f
            tb.setColor(if (on) yellow else offTrack)
            track.background = tb
            val kb = GradientDrawable()
            kb.shape = GradientDrawable.OVAL
            kb.setColor(if (on) btnText else offKnob)
            knob.background = kb
            val x = if (on) (w - k - dp(8)).toFloat() else 0f
            if (animate) {
                knob.animate().translationX(x).setDuration(140).start()
            } else {
                knob.translationX = x
            }
        }
        render(false)
        track.layoutParams = LinearLayout.LayoutParams(w, h)
        track.setOnClickListener {
            on = !on
            render(true)
            onChange(on)
        }
        return track
    }
}

private class MaxHeightScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    init {
        isVerticalScrollBarEnabled = false
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
    }
}
