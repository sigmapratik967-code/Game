package com.voidxen.launcher

import android.app.Activity
import android.os.CancellationSignal
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

/** Google (Gmail) sign-in through Android Credential Manager. serverClientId = Web OAuth client ID. */
object GoogleSignIn {
    data class Account(val idToken: String, val name: String, val email: String)

    fun start(activity: Activity, serverClientId: String, onOk: (Account) -> Unit, onFail: (String) -> Unit) {
        val option = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(serverClientId)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        CredentialManager.create(activity).getCredentialAsync(
            activity,
            request,
            CancellationSignal(),
            ContextCompat.getMainExecutor(activity),
            object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                override fun onResult(result: GetCredentialResponse) {
                    val cred = result.credential
                    if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                        try {
                            val g = GoogleIdTokenCredential.createFrom(cred.data)
                            onOk(Account(g.idToken, g.displayName ?: "", g.id))
                        } catch (e: Exception) {
                            onFail(e.message ?: "Google sign-in failed")
                        }
                    } else {
                        onFail("Unsupported credential")
                    }
                }

                override fun onError(e: GetCredentialException) {
                    onFail(e.message ?: e.type)
                }
            }
        )
    }
}
