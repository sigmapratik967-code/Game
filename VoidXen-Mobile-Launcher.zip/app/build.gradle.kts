import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Saari build values launcher.properties se aati hain
val launcherProps = Properties().apply {
    rootProject.file("launcher.properties").inputStream().use { load(it) }
}
fun prop(key: String, def: String): String = launcherProps.getProperty(key, def).trim()

android {
    namespace = "com.voidxen.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = prop("applicationId", "com.voidxen.mobile")
        minSdk = prop("minSdk", "24").toInt()
        targetSdk = 34
        versionCode = prop("versionCode", "1").toInt()
        versionName = prop("versionName", "1.0.0")
        resValue("string", "app_name", prop("appName", "VoidXen Mobile"))
        setProperty("archivesBaseName", prop("apkName", "VoidXen-Mobile"))
    }

    signingConfigs {
        create("voidxen") {
            storeFile = rootProject.file(prop("keystoreFile", "keystore/voidxen.keystore"))
            storeType = "pkcs12"
            storePassword = prop("keystorePassword", "voidxen123")
            keyAlias = prop("keyAlias", "voidxen")
            keyPassword = prop("keyPassword", "voidxen123")
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("voidxen")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("voidxen")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    // Google Sign-In (Credential Manager)
    implementation("androidx.credentials:credentials:1.2.2")
    implementation("androidx.credentials:credentials-play-services-auth:1.2.2")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.0")
}
