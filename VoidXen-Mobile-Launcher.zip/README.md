# VoidXen Mobile - Game Launcher

Flow: Splash (Checking for game updates) -> Login -> Home (Play / News / Support / Settings) -> Server list -> **Connect screen** -> game.

### Login (reference jaisa): Google / Discord / Guest
Pehli baar app khulte hi login screen aati hai. Session save rehta hai, to agli baar seedha Home.
- **Guest**: hamesha chalta hai (Guest_xxxxxx naam, is device par).
- **Google (Gmail)**: `googleClientId` me *Web application* OAuth client ID daalo.
  Google Cloud Console -> Credentials: ek *Android* OAuth client banao: package `com.voidxen.mobile`,
  SHA-1 `5F:3E:97:FA:50:24:04:2F:CC:8D:9B:D9:DC:13:52:2D:6E:4E:CC:40` (is project ki fixed key ka). Consent screen configure karo.
- **Discord**: `discordClientId` daalo. Discord Developer Portal -> OAuth2 -> Redirects me `voidxen://auth` add karo.
- `authApiUrl` (https, optional): aapka backend identity verify karke session token deta hai.
  POST JSON: `{"action":"google"|"discord"|"guest","nickname":"..", "idToken":".." | "accessToken":"..","discordId":".." | "guestId":".."}`
  Reply: `{"ok":true,"token":"..","nickname":"..","balance":"123"}` ya `{"ok":false,"error":".."}`.
  Khali ho to login sirf is device par hota hai (server verify nahi karta).
- Game ko Intent extras milte hain: nickname, auth_token, server_name, server_ip, server_port, graphics_quality, language, data_dir.
  Token ki asli verification aapke game server ko karni hogi.
- Signing key (`keystore/voidxen.keystore`) repo me hai taaki har build ka SHA-1 same rahe. Repo public hai to
  release se pehle apni private key GitHub Secrets me rakho.

### Connect screen (Play dabane par)
4 real steps: 1) player profile/login 2) game files (installed / download / update / install)
3) server address + live status 4) game launch. Koi step fail ho to saaf reason + Retry/Download/Update/Install/Login button.
Game files na hon to yahin "Cannot connect: Game files not found" dikhta hai. Server offline ho tab bhi game launch hota hai
(warning ke saath), aage ka connect game khud karta hai.

## 1. Build config (ek hi file): `launcher.properties`
appName, apkName, applicationId (package), versionName, versionCode, minSdk, buildType.
GitHub Actions APK ko `<apkName>.apk` naam se bahar nikalta hai.
Launcher icon: `app/src/main/res/drawable/ic_launcher_foreground.xml` + `values/colors.xml (ic_bg)`.

## 2. Runtime config (ek hi file): `app/src/main/assets/launcher_config.json`
Top level: supportUrl (Discord), rulesUrl, newsUrl (JSON array), profileApiUrl, authApiUrl, googleClientId, discordClientId, remoteConfigUrl, news[], servers[].
Har server:
| field | kaam |
|---|---|
| name / firstname / secondname | card label (#001 + tag) |
| ip, port | server address (status query + game ko pass hota hai) |
| statusUrl | optional JSON API: players/online/count, maxplayers/maxonline/max, status |
| downloadUrl | Dropbox link (har server ka alag) |
| downloadFile | save hone wala naam (.apk ya .zip) |
| sha256 | file validation (khali = sirf size check) |
| version | badlo to launcher "Update" dikhata hai |
| gamePackage | game ka package name (launch ke liye) |
| color, x2 | card border colour, x2 tag |

Bina rebuild ke badalna: Dropbox pe config JSON rakho (object ya sirf servers ka array) ->
app me Settings -> "Server config link" me paste karo, ya `remoteConfigUrl` me daalo.

## 3. Live data (fake nahi)
- Player count: statusUrl API, ya (statusUrl khali ho) SA-MP UDP query ip:port par.
- Jab data na mile to "Status unavailable" / "Offline" dikhta hai, kabhi bana hua number nahi.
- Balance: profileApiUrl?nick=<name> se `{"balance": ...}`; na ho to "—".

## 4. Downloads
Resume (HTTP Range, .part file), progress, error messages, SHA-256 validation, Wi-Fi only option,
zip extract (zip-slip safe), APK install prompt. App foreground me rehni chahiye (screen on rakha jata hai);
beech me ruke to dobara dabane par resume hota hai.

## 5. Game ko kya milta hai
Launch intent extras: nickname, server_name, server_ip, server_port, graphics_quality, language, data_dir.
Aapke game client ko ye extras padhne honge.

## 6. DEX
Dekho `docs/DEX.md`.

## Look & feel
Backgrounds `res/drawable-nodpi/bg_sharp.jpg` (2880x1296) aur `bg_blur.jpg` original artwork hain; apni image
(jiske rights aapke paas hon) isi naam se replace kar do. Home/login par sharp, baaki screens par blurred + halka zoom animation.
